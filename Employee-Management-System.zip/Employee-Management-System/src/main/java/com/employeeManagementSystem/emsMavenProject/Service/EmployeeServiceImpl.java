package com.employeeManagementSystem.emsMavenProject.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeManagementSystem.emsMavenProject.Dao.EmployeeDao;
import com.employeeManagementSystem.emsMavenProject.Entity.EmployeeEntity;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDao dao;

	@Override
	public List<EmployeeEntity> getAllEmplData() {
		return dao.findAll();
	}

	@Override
	public Optional<EmployeeEntity> getEmplData(Long employeeId) {
		return dao.findById(employeeId);
	}

	@Override
	public EmployeeEntity addEmplData(EmployeeEntity empl) {
		return dao.save(empl);
	}

	@Override
	public  EmployeeEntity updateEmplData(Long employeeId, EmployeeEntity empl) {
		Optional<EmployeeEntity> checkId=dao.findById(employeeId);
		if(checkId.isPresent()) {
			EmployeeEntity saveId=checkId.get();
			saveId.seteFirst_Name(empl.geteFirst_Name());
			saveId.seteLast_Name(empl.geteLast_Name());
			return dao.save(saveId);
		}
		return null;
	}

	@Override
	public String deleteEmplData(EmployeeEntity employeeId) {
		dao.delete(employeeId);
		return " Data deleted Succesfully";
	}

}
