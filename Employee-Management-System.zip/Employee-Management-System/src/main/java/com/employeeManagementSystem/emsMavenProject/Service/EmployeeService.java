package com.employeeManagementSystem.emsMavenProject.Service;

import java.util.List;
import java.util.Optional;

import com.employeeManagementSystem.emsMavenProject.Entity.EmployeeEntity;

public interface EmployeeService {

	List<EmployeeEntity> getAllEmplData();

	Optional<EmployeeEntity> getEmplData(Long employeeId);

	EmployeeEntity addEmplData(EmployeeEntity empl);

	EmployeeEntity updateEmplData(Long employeeId, EmployeeEntity empl);

	String deleteEmplData(EmployeeEntity employeeId);

}
