package com.employeeManagementSystem.emsMavenProject.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employeeManagementSystem.emsMavenProject.Entity.EmployeeEntity;
import com.employeeManagementSystem.emsMavenProject.Service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	EmployeeService service;

	// Get All Employee
	@GetMapping
	public List<EmployeeEntity> getAllEmplData() {
		return this.service.getAllEmplData();
	}

	// Get Employee By Id
	@GetMapping("/{employeeId}")
	public Optional<EmployeeEntity> getEmplData(@PathVariable String employeeId) {
		return this.service.getEmplData(Long.parseLong(employeeId));
	}

	// Post Employee
	@PostMapping
	public EmployeeEntity addEmplData(@RequestBody EmployeeEntity empl) {
		return this.service.addEmplData(empl);
	}

	// Update Employee By Id
	@PutMapping("/{employeeId}")
	public Object updatEmplData(@PathVariable Long employeeId, @RequestBody EmployeeEntity empl) {
		return this.service.updateEmplData(employeeId, empl);
	}

	// Delete Employee By Id
	@DeleteMapping("/{employeeId}")
	public String deleteEmplData(@PathVariable EmployeeEntity employeeId) {
		return this.service.deleteEmplData(employeeId);

	}

}
