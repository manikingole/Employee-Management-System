package com.employeeManagementSystem.emsMavenProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmsMavenProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmsMavenProjectApplication.class, args);
	}

}
