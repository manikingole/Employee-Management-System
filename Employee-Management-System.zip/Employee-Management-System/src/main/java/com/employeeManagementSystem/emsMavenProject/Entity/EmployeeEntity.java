package com.employeeManagementSystem.emsMavenProject.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EmployeeEntity {
	@Id
	private Long eId;
	private String eFirst_Name;
	private String eLast_Name;
	private String eEmail;
	private String eDesignation;
	private double eSalary;
	
	
	public Long geteId() {
		return eId;
	}
	public void seteId(Long eId) {
		this.eId = eId;
	}
	public String geteFirst_Name() {
		return eFirst_Name;
	}
	public void seteFirst_Name(String eFirst_Name) {
		this.eFirst_Name = eFirst_Name;
	}
	public String geteLast_Name() {
		return eLast_Name;
	}
	public void seteLast_Name(String eLast_Name) {
		this.eLast_Name = eLast_Name;
	}
	public String geteEmail() {
		return eEmail;
	}
	public void seteEmail(String eEmail) {
		this.eEmail = eEmail;
	}
	public String geteDesignation() {
		return eDesignation;
	}
	public void seteDesignation(String eDesignation) {
		this.eDesignation = eDesignation;
	}
	public double geteSalary() {
		return eSalary;
	}
	public void seteSalary(double eSalary) {
		this.eSalary = eSalary;
	}
	@Override
	public String toString() {
		return "EmployeeEntity [eId=" + eId + ", eFirst_Name=" + eFirst_Name + ", eLast_Name=" + eLast_Name
				+ ", eEmail=" + eEmail + ", eDesignation=" + eDesignation + ", eSalary=" + eSalary + "]";
	}
	



}
