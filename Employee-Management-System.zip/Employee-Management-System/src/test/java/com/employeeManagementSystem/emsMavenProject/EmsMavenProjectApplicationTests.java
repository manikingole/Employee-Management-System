package com.employeeManagementSystem.emsMavenProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsMavenProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
